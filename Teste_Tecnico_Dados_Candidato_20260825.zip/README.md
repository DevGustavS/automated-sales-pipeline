# Teste Técnico — Base Comercial Automotiva | Pacote de Dados 20260825

## Contexto dos dados

Os arquivos deste pacote representam uma **base totalmente fictícia e anonimizada**
de operações comerciais de um grupo automotivo multimarcas.

O conjunto foi preparado para simular uma situação próxima de um ambiente corporativo:
há cadastros de apoio (dimensões) e arquivos de vendas recebidos em lotes ao longo do tempo.

## Estrutura

```text
dados/
├── dimensoes/
│   ├── dim_lojas.csv
│   ├── dim_consultores.csv
│   └── dim_veiculos.csv
└── vendas/
    ├── vendas_2024.csv
    ├── vendas_2025.csv
    ├── vendas_2026_01.csv
    ├── vendas_2026_02.csv
    ├── vendas_2026_03.csv
    ├── vendas_2026_04.csv
    └── vendas_2026_05.csv

```

-----------------